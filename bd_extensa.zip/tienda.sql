-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-10-2022 a las 20:55:38
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sumatoria`
--

CREATE TABLE `sumatoria` (
  `tvg` int(20) NOT NULL,
  `nombre` text NOT NULL,
  `producto` text NOT NULL,
  `marca` text NOT NULL,
  `valor` int(30) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tienda1`
--

CREATE TABLE `tienda1` (
  `tv1` int(1) NOT NULL,
  `nombre1` text NOT NULL,
  `producto1` text NOT NULL,
  `marca1` text NOT NULL,
  `cantidad1` int(255) NOT NULL,
  `valor1` int(30) NOT NULL,
  `fecha1` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tienda1`
--

INSERT INTO `tienda1` (`tv1`, `nombre1`, `producto1`, `marca1`, `cantidad1`, `valor1`, `fecha1`) VALUES
(1, 'mike', 'Telefono', 'Xiaomi', 2, 1000, '2022-10-07'),
(2, 'alvaro', 'taza', 'plastic', 2, 5000, '2022-10-05'),
(3, 'leo', 'leche', 'colanta', 1, 4000, '2022-10-12'),
(2, 'mike', 'Telefono', 'rog', 2, 4000, '2022-10-12'),
(3, 'alvaro', 'taza', 'rog', 2, 10000, '2022-10-12'),
(2, 'leo', 'termo', 'imusa', 1, 5000, '2022-10-05'),
(3, 'mike', 'termo', 'imusa', 1, 4000, '2022-10-11'),
(3, 'leo', 'mochila', 'nike', 1, 18000, '2022-10-27'),
(3, 'alvaro', 'foco', 'blankq', 4, 16000, '2022-10-12'),
(2, 'mike', 'adaptador usb', 'tech', 1, 8000, '2022-10-16'),
(1, 'mike', 'lampara led', 'nisza', 2, 20000, '2022-10-25'),
(1, 'alvaro', 'gorra', 'nike', 1, 3000, '2022-10-21'),
(1, 'alvaro', 'gaseosa', 'pepsi', 4, 10000, '2022-10-25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tienda2`
--

CREATE TABLE `tienda2` (
  `tv2` int(1) NOT NULL,
  `nombre2` text NOT NULL,
  `producto2` text NOT NULL,
  `marca2` text NOT NULL,
  `cantidad2` int(20) NOT NULL,
  `valor2` int(30) NOT NULL,
  `fecha2` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tienda2`
--

INSERT INTO `tienda2` (`tv2`, `nombre2`, `producto2`, `marca2`, `cantidad2`, `valor2`, `fecha2`) VALUES
(2, 'alvaro', 'arroz', 'la playita', 12, 32800, '2022-10-19'),
(2, 'mike', 'gaseosa', 'coca cola', 3, 8900, '2022-10-11');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tienda3`
--

CREATE TABLE `tienda3` (
  `tv3` int(1) NOT NULL,
  `nombre3` text NOT NULL,
  `producto3` text NOT NULL,
  `marca3` text NOT NULL,
  `cantidad3` int(20) NOT NULL,
  `valor3` int(20) NOT NULL,
  `fecha3` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tienda3`
--

INSERT INTO `tienda3` (`tv3`, `nombre3`, `producto3`, `marca3`, `cantidad3`, `valor3`, `fecha3`) VALUES
(0, 'mike', 'leche', 'colanta', 2, 5000, '2022-10-19'),
(0, 'mike', 'leche', 'colanta', 1, 2000, '2022-10-02'),
(3, 'alvaro', 'Aceite', 'girasol', 2, 19000, '2022-10-20');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
