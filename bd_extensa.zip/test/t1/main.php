<!DOCTYPE html>
<html lang="en" dir="ltr">
 <head>
<title>Tienda 1</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

 </head>



 <body>
    <div>
	</div>
	<br>
  <br>
  <center>
	<header class="header">
		<div class="container">
			
			</div>
			<nav class="menu">
				//<a href="../total.php">Inicio</a>/
				/<a href="pages/ventas.php">Tabla General</a>/
							</nav>
		</div>
	</header>	
</center>
	<br>

	<center>
	<center><h1>Registrar Venta</h1></center>
<form action="conexion.php" method="post">
 <fieldset class="scheduler-border">

<br>
  <input type="number" name="tv1"  id="tv1" placeholder="Estas en Tienda 1" required>
<br>
  <input type="text" name="nombre1"  id="nombre1" placeholder="Nombre del Vendedor" required  >
<br>
  <input type="text" name="producto1" id="producto1" placeholder="producto" >
<br>
  <input type="text" name="marca1" id="marca1" placeholder="marca" >
<br>   
    <input type="number" name="cantidad1"id="cantidad1" placeholder="cantidad" >
<br>  
  <input type="number" name="valor1" id="valor1" placeholder="precio total de venta" required>
 <br>   
  <input type="date" name="fecha1" id="fecha1" required >
</center>

<center>
	<br>

<button type="submit" name="enviar" class="btn btn-success">Guardar</button>
<input type="reset" class="btn btn-deletes" name="btn0" value="Borrar">
<br>
</center>

 </fieldset>
</form>



 </body>
</html>

