<!DOCTYPE html>
<?php
$conexion = mysqli_connect('localhost','root','','tienda' ) 
or die(mysql_error($mysqli));


include("cn.php");
$tienda1= "SELECT * FROM tienda1";
?>


<html lang="en" dir="ltr">
 <head>
<title>Inventario de Tiendas</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href = " css / estilos.css " rel = " stylesheet " >
  <link rel = " stylesheet " href ="https://maxcdn.bootstrapcdn.com/bootstrap/3.5.6/css/bootstrap.min.css " >
 </head>

 <body>
 <header class="header">
		<div class="container">
		<div class="btn-menu">
			<div class="logo">
			</div>
			<nav class="menu">
				<a href="../main.php">Inicio</a>
				<a href="../pages/ventas.php">Tabla General</a>
				<a href="../consl/registro.php">Filtrar</a>
			</nav>
		</div>
	</header>		


	<center><h1>Listado de la Tienda 1</h1></center>
<br>
<br>
<table class="table table-bordered">

 <tr>  
	    <th>Tienda</th>
        <th>Nombre </th>
        <th>Producto</th>
        <th>Marca</th>
		<th>Cantidad</th>
		<th>Valor</th>
		<th>Fecha</th>
      </tr>
<?php $resultado = mysqli_query($conexion,$tienda1);
while($row=mysqli_fetch_assoc($resultado)){?>
<tr>
    <th class="table__item"><?php echo
	$row["tv1"];?></th>
	<th class="table__item"><?php echo
	$row["nombre1"];?></th>
	<th class="table__item"><?php echo
	$row["producto1"];?></th>
	<th class="table__item"><?php echo
	$row["marca1"];?></th>
	<th class="table__item"><?php echo
	$row["cantidad1"];?></th>
	<th class="table__item"><?php echo
	$row["valor1"];?></th>
	<th class="table__item"><?php echo
	$row["fecha1"];?></th>
	<?php
	
}mysqli_free_result($resultado);?>

</table>

<center> 
	<br>
    <input type="button" class="btn btn-success" onclick="history.back()" name="atras" value="volver atrás">
    </center>

 </body>
 </html>