<?php
$conexion = mysqli_connect("localhost","root","","tienda");
mysqli_set_charset($conexion,"utf8");



?>