<?php
$conexion = mysqli_connect('localhost','root','','tienda' ) 
or die(mysql_error($mysqli));


insertar($conexion);

function insertar($conexion){
	$tv2       =   $_POST['tv2'];
	$nombre2   =   $_POST['nombre2'];
	$producto2 =   $_POST['producto2']; 
	$marca2    =   $_POST['marca2'];
	$cantidad2 =   $_POST['cantidad2']; 
	$valor2    =   $_POST['valor2']; 
	$fecha2    =   $_POST['fecha2']; 

	
	$consulta = "INSERT INTO tienda2(tv2, nombre2, producto2, marca2, cantidad2, valor2, fecha2)
	VALUES ('$tv2','$nombre2','$producto2','$marca2','$cantidad2','$valor2','$fecha2')";
	
	mysqli_query($conexion, $consulta);
	mysqli_close($conexion);
	
	if($consulta){
	
		echo "<script>
		
		alert('Registro insertado');
		window.location='main.php';
		</script>";
	}else {
		echo
		"<script>
		alert('existe alguna falla, favor de intentar nuevamente');
		window.location = 'main.php';
		</script>";
	}	
	
	
}


?>
	
