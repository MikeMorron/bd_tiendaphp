<?php
$conexion = mysqli_connect('localhost','root','','tienda' ) 
or die(mysql_error($mysqli));


insertar($conexion);

function insertar($conexion){
	$tv3       =   $_POST['tv3'];
	$nombre3   =   $_POST['nombre3'];
	$producto3 =   $_POST['producto3']; 
	$marca3    =   $_POST['marca3'];
	$cantidad3 =   $_POST['cantidad3']; 
	$valor3    =   $_POST['valor3']; 
	$fecha3    =   $_POST['fecha3']; 

	
	$consulta = "INSERT INTO tienda3(tv3, nombre3, producto3, marca3, cantidad3, valor3, fecha3)
	VALUES ('$tv3','$nombre3','$producto3','$marca3','$cantidad3','$valor3','$fecha3')";
	
	mysqli_query($conexion, $consulta);
	mysqli_close($conexion);
	
	if($consulta){
	
		echo "<script>
		
		alert('Registro insertado');
		window.location='main.php';
		</script>";
	}else {
		echo
		"<script>
		alert('existe alguna falla, favor de intentar nuevamente');
		window.location = 'main.php';
		</script>";
	}	
	
	
}


?>
	
