<html>
<head>
  <title>Inicio</title>
</head>

<body>

<div>
	</div>
	<br>
  <br>
  <center>
	<header class="header">
		<div class="container">
			
			</div>
			<nav class="menu">
            <a title="Tienda 1" href="t1/main.php"><img src="https://cdn-icons-png.flaticon.com/512/1345/1345040.png" width="100" height="100" />Tienda 1</a>
			<br>
			
			<a title="Tienda 2" href="t2/main.php"><img src="https://cdn-icons-png.flaticon.com/512/1345/1345040.png" width="100" height="100" />Tienda 2</a>
			<br>
		
            <a title="Tienda 3" href="t3/main.php"><img src="https://cdn-icons-png.flaticon.com/512/1345/1345040.png" width="100" height="100" />Tienda 3</a>	
				
			</nav>
		</div>
	</header>	
</center>
	<br>




    <center> 
	<br>
	<a href="filtro.php">
    <button class=btn-btn>Filtrar</button>
  </a> 
    </center>

    <br>



<?php
/*valor*/
include("t1/consl/abrir_conexion.php");

    $consulta =" SELECT valor1  FROM tienda1 ";
    $resultado = mysqli_query ( $conexion , $consulta ) or die ( " Algo ha ido mal!" ) ;


	$total=0;

	$count=mysqli_num_rows($resultado);
    if($count > 0){
    while($columna=mysqli_fetch_array($resultado)){
		echo "<tr>";
		echo"<table>";		
	    echo "</tr>";
		$total+=$columna['valor1'];
    }
}
	
      
	echo "</table>";
	echo "<table>";
	echo "<td>Total Ganancias del mes en tienda 1 = </td>";
	echo "<td>".$total."</td>";
	echo "</table>";
 
    mysqli_close ( $conexion ) ;
	?>

<?php
/*valor 2*/
include("t1/consl/abrir_conexion.php");

    $consulta =" SELECT valor2  FROM tienda2 ";
    $resultado = mysqli_query ( $conexion , $consulta ) or die ( " Algo ha ido mal!" ) ;


	$total=0;

	$count=mysqli_num_rows($resultado);
    if($count > 0){
    while($columna=mysqli_fetch_array($resultado)){
		echo "<tr>";
		echo"<table>";		
	    echo "</tr>";
		$total+=$columna['valor2'];
    }
}
	
      
	echo "</table>";
	echo "<table>";
	echo "<td>Total Ganancias del mes en tienda 2 = </td>";
	echo "<td>".$total."</td>";
	echo "</table>";
 
    mysqli_close ( $conexion ) ;
	?>


<?php
/*valor 2*/
include("t1/consl/abrir_conexion.php");

    $consulta =" SELECT valor3  FROM tienda3 ";
    $resultado = mysqli_query ( $conexion , $consulta ) or die ( " Algo ha ido mal!" ) ;


	$total=0;

	$count=mysqli_num_rows($resultado);
    if($count > 0){
    while($columna=mysqli_fetch_array($resultado)){
		echo "<tr>";
		echo"<table>";		
	    echo "</tr>";
		$total+=$columna['valor3'];
    }
}
	
      
	echo "</table>";
	echo "<table>";
	echo "<td>Total Ganancias del mes en tienda 3 = </td>";
	echo "<td>".$total."</td>";
	echo "</table>";
 
    mysqli_close ( $conexion ) ;
	?>



<br>


<?php
/*productos*/
include("t1/consl/abrir_conexion.php");

    $consulta =" SELECT cantidad1  FROM tienda1 ";
    $resultado = mysqli_query ( $conexion , $consulta ) or die ( " Algo ha ido mal!" ) ;


	$total=0;

	$count=mysqli_num_rows($resultado);
    if($count > 0){
    while($columna=mysqli_fetch_array($resultado)){
		echo "<tr>";
		echo"<table>";		
	    echo "</tr>";
		$total+=$columna['cantidad1'];
    }
}
	
      
	echo "</table>";
	echo "<table>";
	echo "<td>Productos vendidos del mes en tienda 1 = </td>";
	echo "<td>".$total."</td>";
	echo "</table>";
 
    mysqli_close ( $conexion ) ;
	?>



<?php
/*productos 2*/
include("t1/consl/abrir_conexion.php");

    $consulta =" SELECT cantidad2  FROM tienda2 ";
    $resultado = mysqli_query ( $conexion , $consulta ) or die ( " Algo ha ido mal!" ) ;


	$total=0;

	$count=mysqli_num_rows($resultado);
    if($count > 0){
    while($columna=mysqli_fetch_array($resultado)){
		echo "<tr>";
		echo"<table>";		
	    echo "</tr>";
		$total+=$columna['cantidad2'];
    }
}
	
      
	echo "</table>";
	echo "<table>";
	echo "<td>Productos vendidos del mes en tienda 2 = </td>";
	echo "<td>".$total."</td>";
	echo "</table>";
 
    mysqli_close ( $conexion ) ;
	?>

<?php
/*productos 3*/
include("t1/consl/abrir_conexion.php");

    $consulta =" SELECT cantidad3  FROM tienda3 ";
    $resultado = mysqli_query ( $conexion , $consulta ) or die ( " Algo ha ido mal!" ) ;


	$total=0;

	$count=mysqli_num_rows($resultado);
    if($count > 0){
    while($columna=mysqli_fetch_array($resultado)){
		echo "<tr>";
		echo"<table>";		
	    echo "</tr>";
		$total+=$columna['cantidad3'];
    }
}
	
      
	echo "</table>";
	echo "<table>";
	echo "<td>Productos vendidos del mes en tienda 3 = </td>";
	echo "<td>".$total."</td>";
	echo "</table>";
 
    mysqli_close ( $conexion ) ;
	?>

<br>




<br>
<br>






</body>
</html>